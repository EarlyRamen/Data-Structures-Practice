#include "huffman.h"
#include <fstream>

int main(int argc, char const *argv[])
{
    Huffman book = Huffman("War and Peace.txt");
    return 0;
}

